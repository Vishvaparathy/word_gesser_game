package com.example.word_gesser;


import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Random;

public class GameActivity extends AppCompatActivity {

    TextView txtWordLength, txtScore, txtAttempts, txtTimer, txtResult;
    EditText edtGuess;
    Button btnSubmitGuess, btnNewGame, btnGetClue;
    String randomWord;
    int score = 100;
    int attempts = 0;
    CountDownTimer timer;
    long timeLeftInMillis = 60000; // 1 minute

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        txtWordLength = findViewById(R.id.txtWordLength);
        txtScore = findViewById(R.id.txtScore);
        txtAttempts = findViewById(R.id.txtAttempts);
        txtTimer = findViewById(R.id.txtTimer);
        txtResult = findViewById(R.id.txtResult);
        edtGuess = findViewById(R.id.edtGuess);
        btnSubmitGuess = findViewById(R.id.btnSubmitGuess);
        btnNewGame = findViewById(R.id.btnNewGame);
        btnGetClue = findViewById(R.id.btnGetClue);

        startNewGame();

        btnSubmitGuess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String guess = edtGuess.getText().toString().trim().toLowerCase();
                if (!guess.isEmpty()) {
                    checkGuess(guess);
                }
            }
        });

        btnNewGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNewGame();
            }
        });

        btnGetClue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                giveClue();
            }
        });
    }

    private void startNewGame() {
        randomWord = getRandomWord();
        txtWordLength.setText("Word Length: " + randomWord.length());
        score = 100;
        attempts = 0;
        txtScore.setText("Score: " + score);
        txtAttempts.setText("Attempts: " + attempts);
        txtResult.setText("Start guessing the word!");
        edtGuess.setText("");
        btnGetClue.setEnabled(false); // Disable the clue button until 5 attempts
        startTimer();
    }

    private String getRandomWord() {
        // This method should ideally fetch from an API; for now, it picks a random word from a list
        String[] words = {"apple", "banana", "grape", "orange", "mango"};
        Random random = new Random();
        return words[random.nextInt(words.length)];
    }

    private void checkGuess(String guess) {
        attempts++;
        txtAttempts.setText("Attempts: " + attempts);

        if (guess.equals(randomWord)) {
            txtResult.setText("Correct! You guessed the word!");
            timer.cancel(); // Stop the timer when guessed correctly
        } else {
            score -= 10;
            txtScore.setText("Score: " + score);
            txtResult.setText("Incorrect guess. Try again.");

            if (attempts >= 5) {
                btnGetClue.setEnabled(true); // Enable the clue button after 5 incorrect attempts
            }

            if (attempts >= 10 || score <= 0) {
                txtResult.setText("You failed to guess. The word was: " + randomWord);
                timer.cancel(); // Stop the timer when failed
            }
        }
    }

    private void giveClue() {
        // Provide a clue (for simplicity, the first letter of the word)
        txtResult.setText("Clue: The word starts with '" + randomWord.charAt(0) + "'");
        btnGetClue.setEnabled(false); // Disable after giving the clue
        score -= 5;
        txtScore.setText("Score: " + score);
    }

    private void startTimer() {
        timer = new CountDownTimer(timeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateTimer();
            }

            @Override
            public void onFinish() {
                txtResult.setText("Time's up! The word was: " + randomWord);
            }
        }.start();
    }

    private void updateTimer() {
        int secondsLeft = (int) (timeLeftInMillis / 1000);
        txtTimer.setText("Time left: " + secondsLeft + "s");
    }
}